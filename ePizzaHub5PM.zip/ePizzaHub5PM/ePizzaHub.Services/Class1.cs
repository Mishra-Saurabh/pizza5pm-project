﻿using System;

namespace ePizzaHub.Services
{
    public class Class1
    {
    }
}
