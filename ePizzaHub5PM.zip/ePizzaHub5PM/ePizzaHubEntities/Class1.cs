﻿using System;

namespace ePizzaHubEntities
{
    public class Class1
    {
    }
}
